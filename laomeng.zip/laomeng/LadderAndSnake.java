
package laomeng;

import java.sql.SQLOutput;
import java.util.Random;
import java.util.Scanner;

public class LadderAndSnake {

    private int numOfPlayers;

    public LadderAndSnake(int numOfPlayers) {
        this.numOfPlayers = numOfPlayers;
        play(numOfPlayers);
    }

    private static int[] createBoard() {
        int num = 1;
        int[] board = new int[100];
        for (int i = 0; i < 100; i++) {
            board[i] = num;
            num ++;
        }
        board[0] = 38;
        board[3] = 14;
        board[8] = 31;
        board[27] = 84;
        board[20] = 42;
        board[35] = 44;
        board[50] = 67;
        board[79] = 100;
        board[70] = 91;
        board[15] = 6;
        board[47] = 30;
        board[61] = 19;
        board[63] = 60;
        board[97] = 78;
        board[96] = 76;
        board[94] = 24;
        board[92] = 68;
        return board;
    }

    private static int flipDice() {
        int dice;
        Random randomNum = new Random();
        dice = randomNum.nextInt(6) + 1;
        return dice;
    }

    public void printLadderAndSnakeBoard() {
        int n = 100;
        for (int i = 10; i > 0; i--) {
            System.out.print("    ");
            for (int j = 10; j > 0; j--) {
                if (i % 2 == 0) {
                    System.out.print(String.format("%02d\t", n) + " ");
                    n--;
                    if (j == 1) {
                        n -= 9;
                    }
                } else {
                    System.out.print(String.format("%02d\t", n) + " ");
                    n++;
                    if (j == 1) {
                        n -= 11;
                    }
                }
            }
            System.out.println();
        }
    }

    public void play(int numOfPlayers) {
        boolean flag = true;
        int tempPosition = 0;
        Player tempPlayer = new Player();

        Player[] players = new Player[numOfPlayers];
        int[] board = createBoard();
        System.out.println();
        System.out.println("This is the game board!");
        printLadderAndSnakeBoard();
        Scanner input = new Scanner(System.in);

        String temp = "";

        System.out.println();
        System.out.println("This game is played by " + numOfPlayers + " players");
        for (int i = 0; i < numOfPlayers; i++) {
            System.out.println("Please enter #" + (i + 1) + " Player's name:");
            players[i] = new Player();
            temp = input.next();
            players[i].setName(temp);

        }
        System.out.println("We have " + numOfPlayers + " players, their names are:");
        for (int i = 0; i < players.length; i++) {
            System.out.println(players[i].getName());
        }


        System.out.println("Now deciding which player will start playing first.");
        for (int i = 0; i < players.length; i++) {
            players[i].setCurrentPosition(flipDice());
            System.out.println("Player " + players[i].getName() + " got a dice value of " + players[i].getCurrentPosition());
        }

        while(flag){
            flag = false;

            if (numOfPlayers == 2) {
                if(players[0].getCurrentPosition() == players[1].getCurrentPosition()){
                    System.out.println("A tie was achieved between " + players[0].getName() + ", " + players[1].getName() + ". Attempting to break the tie");
                    players[0].setCurrentPosition(flipDice());
                    players[1].setCurrentPosition(flipDice());
                    flag = true;
                }
            }

            if (numOfPlayers == 3){
                if(players[0].getCurrentPosition() == players[1].getCurrentPosition() && players[1].getCurrentPosition() == players[2].getCurrentPosition()) {
                    System.out.println("A tie was achieved between " + players[0].getName() + ", " + players[1].getName() + " and " + players[2].getName() +
                            ". Attempting to break the tie");
                    players[0].setCurrentPosition(flipDice());
                    players[1].setCurrentPosition(flipDice());
                    players[2].setCurrentPosition(flipDice());
                    System.out.println("Player " + players[0].getName() + " got dice value of " + players[0].getCurrentPosition());
                    System.out.println("Player " + players[1].getName() + " got dice value of " + players[1].getCurrentPosition());
                    System.out.println("Player " + players[2].getName() + " got dice value of " + players[2].getCurrentPosition());
                    flag = true;
                }else{
                    for (int i = 0; i < players.length; i++){
                        for (int j = i + 1; j < players.length; j++){
                            if (players[i].getCurrentPosition() == players[j].getCurrentPosition()) {
                                System.out.println("A tie was achieved between " + players[i].getName() + " and " + players[j].getName());
                                players[i].setCurrentPosition(flipDice());
                                players[j].setCurrentPosition(flipDice());
                                System.out.println("Player " + players[i].getName() + " got dice value of " + players[i].getCurrentPosition());
                                System.out.println("Player " + players[j].getName() + " got dice value of " + players[j].getCurrentPosition());
                                flag = true;
                            }
                        }
                    }
                }
            }

            if(numOfPlayers == 4){
                if(players[0].getCurrentPosition() == players[1].getCurrentPosition() && players[1].getCurrentPosition() == players[2].getCurrentPosition()){
                    System.out.println("A tie was achieved between " + players[0].getName() + ", " + players[1].getName() + " and " + players[2].getName() +
                            ". Attempting to break the tie");
                    players[0].setCurrentPosition(flipDice());
                    players[1].setCurrentPosition(flipDice());
                    players[2].setCurrentPosition(flipDice());
                    System.out.println("Player " + players[0].getName() + " got dice value of " + players[0].getCurrentPosition());
                    System.out.println("Player " + players[1].getName() + " got dice value of " + players[1].getCurrentPosition());
                    System.out.println("Player " + players[2].getName() + " got dice value of " + players[2].getCurrentPosition());
                    flag = true;
                }
                if(players[1].getCurrentPosition() == players[2].getCurrentPosition() && players[2].getCurrentPosition() == players[3].getCurrentPosition()){
                    System.out.println("A tie was achieved between " + players[1].getName() + ", " + players[2].getName() + " and " + players[3].getName() +
                            ". Attempting to break the tie");
                    players[1].setCurrentPosition(flipDice());
                    players[2].setCurrentPosition(flipDice());
                    players[3].setCurrentPosition(flipDice());
                    System.out.println("Player " + players[1].getName() + " got dice value of " + players[0].getCurrentPosition());
                    System.out.println("Player " + players[2].getName() + " got dice value of " + players[1].getCurrentPosition());
                    System.out.println("Player " + players[3].getName() + " got dice value of " + players[2].getCurrentPosition());
                    flag = true;
                }
                if(players[0].getCurrentPosition() == players[2].getCurrentPosition() && players[2].getCurrentPosition() == players[3].getCurrentPosition()){
                    System.out.println("A tie was achieved between " + players[0].getName() + ", " + players[2].getName() + " and " + players[3].getName() +
                            ". Attempting to break the tie");
                    players[0].setCurrentPosition(flipDice());
                    players[2].setCurrentPosition(flipDice());
                    players[3].setCurrentPosition(flipDice());
                    System.out.println("Player " + players[0].getName() + " got dice value of " + players[0].getCurrentPosition());
                    System.out.println("Player " + players[2].getName() + " got dice value of " + players[1].getCurrentPosition());
                    System.out.println("Player " + players[3].getName() + " got dice value of " + players[2].getCurrentPosition());
                    flag = true;
                }
                if(players[0].getCurrentPosition() == players[1].getCurrentPosition() && players[1].getCurrentPosition() == players[3].getCurrentPosition()){
                    System.out.println("A tie was achieved between " + players[0].getName() + ", " + players[1].getName() + " and " + players[3].getName() +
                            ". Attempting to break the tie");
                    players[0].setCurrentPosition(flipDice());
                    players[1].setCurrentPosition(flipDice());
                    players[3].setCurrentPosition(flipDice());
                    System.out.println("Player " + players[0].getName() + " got dice value of " + players[0].getCurrentPosition());
                    System.out.println("Player " + players[1].getName() + " got dice value of " + players[1].getCurrentPosition());
                    System.out.println("Player " + players[3].getName() + " got dice value of " + players[2].getCurrentPosition());
                    flag = true;
                }
                if(players[0].getCurrentPosition() == players[1].getCurrentPosition() && players[1].getCurrentPosition() == players[2].getCurrentPosition()
                        && players[2].getCurrentPosition() == players[3].getCurrentPosition()){
                    System.out.println("A tie was achieved between " + players[0].getName() + ", " + players[1].getName() + ", " + players[2].getName() +
                            " and " + players[3].getName() + ". Attempting to break the tie");
                    players[0].setCurrentPosition(flipDice());
                    players[1].setCurrentPosition(flipDice());
                    players[2].setCurrentPosition(flipDice());
                    players[3].setCurrentPosition(flipDice());
                    System.out.println("Player " + players[0].getName() + " got dice value of " + players[0].getCurrentPosition());
                    System.out.println("Player " + players[1].getName() + " got dice value of " + players[1].getCurrentPosition());
                    System.out.println("Player " + players[2].getName() + " got dice value of " + players[2].getCurrentPosition());
                    System.out.println("Player " + players[3].getName() + " got dice value of " + players[3].getCurrentPosition());
                    flag = true;
                }

                for (int i = 0; i < players.length; i++){
                    for (int j = i + 1; j < players.length; j++){
                        if (players[i].getCurrentPosition() == players[j].getCurrentPosition()){
                            System.out.println("A tie was achieved between " + players[i].getName() + " and " + players[j].getName());
                            players[i].setCurrentPosition(flipDice());
                            players[j].setCurrentPosition(flipDice());
                            System.out.println("Player " + players[i].getName() + " got dice value of " + players[i].getCurrentPosition());
                            System.out.println("Player " + players[j].getName() + " got dice value of " + players[j].getCurrentPosition());
                            flag = true;
                        }
                    }
                }
            }
        }

        flag = true;
        while(flag){
            flag = false;
            for (int i = 0; i < players.length - 1; i++){
                if (players[i].getCurrentPosition() < players[i + 1].getCurrentPosition()){
                    tempPlayer = players[i];
                    players[i] = players[i + 1];
                    players[i + 1] = tempPlayer;
                    flag = true;
                }
            }
        }

        System.out.print("Reached final decision on order of playing: ");
        for (int i = 0; i < players.length; i ++){
            players[i].setCurrentPosition(0);
            if (i != (players.length - 1)){
                System.out.print(players[i].getName() + ", ");
            }else{
                System.out.print(players[players.length - 1].getName());
            }
        }
        System.out.println();
        System.out.println("Now the game begins, press any key to continue!");
        input.next();

        flag = false;
        while(!flag) {
            for (int i = 0; i < players.length; i++) {
                tempPosition = flipDice();
                System.out.println("Player " + players[i].getName() + " got dice value of " + tempPosition + ";");

                if ((players[i].getCurrentPosition() + tempPosition) > 100) {
                    tempPosition = (100 - ((players[i].getCurrentPosition() + tempPosition) - 100));
                    players[i].setCurrentPosition(tempPosition);
                    if (tempPosition == board[tempPosition - 1]) {
                        players[i].setCurrentPosition(tempPosition);
                        System.out.print(players[i].getName() + " now in square " + players[i].getCurrentPosition());
                    }
                    if (tempPosition > board[tempPosition - 1]) {
                        players[i].setCurrentPosition(board[tempPosition - 1]);
                        System.out.print(players[i].getName() + " gone to square " + tempPosition + " then down to square " + players[i].getCurrentPosition());
                        System.out.println();
                    }
                } else if ((players[i].getCurrentPosition() + tempPosition) == board[(players[i].getCurrentPosition() + tempPosition) - 1]) {
                    tempPosition += players[i].getCurrentPosition();
                    players[i].setCurrentPosition(tempPosition);
                    System.out.println(players[i].getName() + " now in square " + players[i].getCurrentPosition());
                    System.out.println();
                } else if ((players[i].getCurrentPosition() + tempPosition) < board[(players[i].getCurrentPosition() + tempPosition) - 1]) {
                    tempPosition += players[i].getCurrentPosition();
                    players[i].setCurrentPosition(board[tempPosition - 1]);
                    System.out.print(players[i].getName() + " gone to square " + tempPosition + " then up to square " + players[i].getCurrentPosition());
                    System.out.println();
                } else if ((players[i].getCurrentPosition() + tempPosition) > board[(players[i].getCurrentPosition() + tempPosition) - 1]) {
                    tempPosition += players[i].getCurrentPosition();
                    players[i].setCurrentPosition(board[tempPosition - 1]);
                    System.out.print(players[i].getName() + " gone to square " + tempPosition + " then down to square " + players[i].getCurrentPosition());
                    System.out.println();
                } else {
                }
                if (players[i].getCurrentPosition() == 100) {
                    System.out.println("We have the winner now! " + players[i].getName() + " has won the game!");
                    flag = true;
                    break;
                }
                System.out.println();
            }
            if (!flag){
                System.out.print    ("Game not over; flipping again");
                System.out.println("Enter any key to continue!");
                input.next();
            }else{
                break;
            }
        }
    }
}

